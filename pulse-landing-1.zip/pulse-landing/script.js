const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.14 });
document.querySelectorAll('.reveal').forEach((element) => observer.observe(element));

const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');
menuToggle.addEventListener('click', () => {
  const open = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
navLinks.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  navLinks.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

const flavorThemes = {
  cherry: { pink: '#ff2c78', glow: '#ff287c55' },
  citrus: { pink: '#c4f33a', glow: '#b8ff3650' },
  blue: { pink: '#718aff', glow: '#526fff55' }
};
document.querySelectorAll('.flavor-card').forEach((card) => {
  card.addEventListener('mouseenter', () => {
    const theme = flavorThemes[card.dataset.flavor];
    document.documentElement.style.setProperty('--pink', theme.pink);
    document.querySelector('.product-glow').style.background = `radial-gradient(circle, ${theme.glow}, transparent 68%)`;
  });
});
document.querySelector('.flavors').addEventListener('mouseleave', () => {
  document.documentElement.style.setProperty('--pink', '#ff2c78');
  document.querySelector('.product-glow').style.background = 'radial-gradient(circle, #ff287c55, transparent 68%)';
});
