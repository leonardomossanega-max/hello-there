# PULSE® — Break the Ordinary

Landing page conceitual de uma marca fictícia de energy drink, inspirada no vídeo de referência enviado pelo usuário: visual escuro cinematográfico, magenta neon, produto central, animações de flutuação, texto condensado, seção de sabores e microinterações.

## Estrutura

- `index.html` — estrutura semântica da página.
- `styles.css` — identidade visual, responsividade e animações.
- `script.js` — animações de entrada, menu mobile e interações de sabor.
- `assets/pulse-mark.svg` — marca vetorial.

## Executar localmente

Abra `index.html` no navegador. Não é necessário instalar dependências ou executar build.

## Publicar no GitHub Pages

1. Envie todos os arquivos e pastas para a raiz do repositório.
2. No GitHub, abra **Settings → Pages**.
3. Em **Build and deployment**, escolha **Deploy from a branch**.
4. Selecione a branch `main` e a pasta `/(root)` e salve.

## Nota

PULSE é uma marca conceitual criada para este protótipo. Não representa um produto comercial real e não contém alegações nutricionais.
